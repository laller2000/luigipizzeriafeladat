-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2019. Ápr 16. 09:36
-- Kiszolgáló verziója: 10.1.37-MariaDB
-- PHP verzió: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `tuttipizza`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `italok`
--

CREATE TABLE `italok` (
  `ID` int(11) NOT NULL,
  `nev` varchar(20) NOT NULL,
  `ar` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `italok`
--

INSERT INTO `italok` (`ID`, `nev`, `ar`) VALUES
(1, 'Coca Cola', 220),
(2, 'Dreher Bak', 300);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `megrendeles`
--

CREATE TABLE `megrendeles` (
  `ID` int(11) NOT NULL,
  `Datum` datetime NOT NULL,
  `felhasz_ID` int(11) NOT NULL,
  `pizza_ID` int(11) DEFAULT NULL,
  `ital_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `felhasz`
--

CREATE TABLE `felhasz` (
  `ID` int(11) NOT NULL,
  `username` varchar(40) NOT NULL,
  `szolgaltato` int(4) NOT NULL,
  `phone` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `felhasz`
--

INSERT INTO `felhasz` (`ID`, `username`, `szolgaltato`, `phone`, `email`, `password`) VALUES
(1, 'Imre', 620, 12345678, 'email@gmail.com', 'asdasd'),
(2, 'Imre', 620, 12121212, 'sasd@gmail.com', 'asss'),
(3, 'Imre', 620, 121212, 'Ema@gmail.com', 'sdsdsd'),
(4, 'Imre', 620, 12345678, 'e@gmail.com', 'sdsd'),
(5, 'Imre', 620, 1212121, 'dd@gmail.com', 'sdasd'),
(6, 'imre', 620, 1223233, 'sd@gmail.com', 'asdasd'),
(7, 'ime', 620, 232323, 'sada@gmail.com', 'dfdf'),
(8, 'sdfsdfd', 620, 2323, 'sdfdf@gmail.com', 'sdfsdf'),
(9, 'sdsad', 620, 1212121, 'sdsad@gmail.com', 'ddddd'),
(10, 'asassas', 620, 232323, 'dsad@gmail.com', 'ssss'),
(11, 'imre', 620, 1233, 'ujsd@gmail.com', 'sssss'),
(12, 'Imrus', 670, 1234567, 'dr@gmail.com', 'asasas'),
(13, 'Imrus', 670, 1234567, 'dddr@gmail.com', 'asasas'),
(14, 'Imree', 620, 3333333, 'sssssd@gmail.com', 'asasasas'),
(15, 'ferike', 630, 121212, 'sdf@freemail.hu', 'qqqq');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pizza`
--

CREATE TABLE `pizza` (
  `ID` int(11) NOT NULL,
  `nev` varchar(20) NOT NULL,
  `ar` int(10) NOT NULL,
  `sajt` enum('igen','nem') NOT NULL DEFAULT 'nem',
  `szosz` enum('igen','nem') NOT NULL DEFAULT 'nem'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `pizza`
--

INSERT INTO `pizza` (`ID`, `nev`, `ar`, `sajt`, `szosz`) VALUES
(15, 'hagymas', 1200, 'nem', 'nem'),
(16, 'szalamis', 1300, 'nem', 'nem'),
(17, 'zoldseges', 1100, 'nem', 'nem'),
(18, 'sajtos', 1000, 'nem', 'nem'),
(19, 'kolbaszos', 1200, 'nem', 'nem'),
(20, 'kukoricas', 1200, 'nem', 'nem'),
(21, 'paradicsomos', 1200, 'nem', 'nem'),
(22, 'baconos', 1500, 'nem', 'nem'),
(23, 'magyaros', 1400, 'nem', 'nem'),
(24, 'gombas', 1300, 'nem', 'nem');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `italok`
--
ALTER TABLE `italok`
  ADD PRIMARY KEY (`ID`);

--
-- A tábla indexei `megrendeles`
--
ALTER TABLE `megrendeles`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `felhasz_ID` (`felhasz_ID`),
  ADD KEY `pizza_ID` (`pizza_ID`),
  ADD KEY `ital_ID` (`ital_ID`);

--
-- A tábla indexei `felhasz`
--
ALTER TABLE `felhasz`
  ADD PRIMARY KEY (`ID`);

--
-- A tábla indexei `pizza`
--
ALTER TABLE `pizza`
  ADD PRIMARY KEY (`ID`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `italok`
--
ALTER TABLE `italok`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `megrendeles`
--
ALTER TABLE `megrendeles`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `felhasz`
--
ALTER TABLE `felhasz`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT a táblához `pizza`
--
ALTER TABLE `pizza`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `megrendeles`
--
ALTER TABLE `megrendeles`
  ADD CONSTRAINT `megrendeles_ibfk_1` FOREIGN KEY (`felhasz_ID`) REFERENCES `felhasz` (`ID`),
  ADD CONSTRAINT `megrendeles_ibfk_2` FOREIGN KEY (`ital_ID`) REFERENCES `italok` (`ID`),
  ADD CONSTRAINT `megrendeles_ibfk_3` FOREIGN KEY (`pizza_ID`) REFERENCES `pizza` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
